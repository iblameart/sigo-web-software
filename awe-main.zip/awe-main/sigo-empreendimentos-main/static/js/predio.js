const urlParams = new URLSearchParams(window.location.search);
const nomePredio = urlParams.get("nome") || "bela-vista";

fetch(`static/data/predios.json`)
  .then(res => res.json())
  .then(data => {
    // Preencher dados do prédio
    document.getElementById("titulo-predio").innerText = data.titulo;
    document.getElementById("localizacao-predio").innerText = data.localizacao;
    document.getElementById("descricao-localizacao").innerText = data.descricao;
    document.getElementById("mapa-local").src = data.mapa;
    document.getElementById("link-contato").href = data.whatsapp;

    // Preencher galeria
    const galeriaSlides = document.getElementById("galeria-slides");
    const galeriaDots = document.getElementById("galeria-dots");
    console.log(data);
    data.forEach((img, i) => {
      galeriaSlides.innerHTML += `<img src="${img.imagem}" class="slide${i === 0 ? ' active' : ''}" alt="Imagem ${i + 1}">`;
      galeriaDots.innerHTML += `<span class="dot${i === 0 ? ' active' : ''}" data-index="${i}"></span>`;
    });

    // Preencher plantas
    const plantaSlides = document.getElementById("planta-slides");
    const plantaDots = document.getElementById("planta-dots");
    data.plantas.forEach((img, i) => {
      plantaSlides.innerHTML += `<img src="${img}" class="slide${i === 0 ? ' active' : ''}" alt="Planta ${i + 1}">`;
      plantaDots.innerHTML += `<span class="dot${i === 0 ? ' active' : ''}" data-index="${i}"></span>`;
    });

    inicializarSliders(); // Ativar sliders após carregar os dados
  });

// SLIDER logic encapsulado
function inicializarSliders() {
  // Galeria principal
  const slides = document.querySelectorAll(".slides .slide");
  const dots = document.querySelectorAll(".dots .dot");
  const prevBtn = document.querySelector(".prev");
  const nextBtn = document.querySelector(".next");
  let currentSlide = 0;

  function showSlide(index) {
    slides.forEach(s => s.classList.remove("active"));
    dots.forEach(d => d.classList.remove("active"));
    slides[index].classList.add("active");
    dots[index].classList.add("active");
  }

  prevBtn.addEventListener("click", () => {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    showSlide(currentSlide);
  });

  nextBtn.addEventListener("click", () => {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
  });

  dots.forEach(dot => {
    dot.addEventListener("click", () => {
      currentSlide = parseInt(dot.dataset.index);
      showSlide(currentSlide);
    });
  });

  setInterval(() => {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
  }, 5000);

  // Galeria de plantas
  const plantaSlides = document.querySelectorAll(".planta-slides .slide");
  const plantaDots = document.querySelectorAll(".planta-dots .dot");
  const plantaPrevBtn = document.querySelector(".planta-prev");
  const plantaNextBtn = document.querySelector(".planta-next");
  let currentPlantaSlide = 0;

  function showPlantaSlide(index) {
    plantaSlides.forEach(s => s.classList.remove("active"));
    plantaDots.forEach(d => d.classList.remove("active"));
    plantaSlides[index].classList.add("active");
    plantaDots[index].classList.add("active");
  }

  plantaPrevBtn.addEventListener("click", () => {
    currentPlantaSlide = (currentPlantaSlide - 1 + plantaSlides.length) % plantaSlides.length;
    showPlantaSlide(currentPlantaSlide);
  });

  plantaNextBtn.addEventListener("click", () => {
    currentPlantaSlide = (currentPlantaSlide + 1) % plantaSlides.length;
    showPlantaSlide(currentPlantaSlide);
  });

  plantaDots.forEach(dot => {
    dot.addEventListener("click", () => {
      currentPlantaSlide = parseInt(dot.dataset.index);
      showPlantaSlide(currentPlantaSlide);
    });
  });

  setInterval(() => {
    currentPlantaSlide = (currentPlantaSlide + 1) % plantaSlides.length;
    showPlantaSlide(currentPlantaSlide);
  }, 6000);
}
